# v0.20论文级实验协议

## 1. 实验目标与冻结规则

本协议用于验证任务驱动流式语义维护是否能在动态室内环境中，提高语义一致性和导航恢复能力，同时降低不必要的感知与记忆更新。

进入正式实验后冻结以下内容：

- `dynamic_indoor_benchmark.sdf`的几何结构；
- 区域和拓扑节点数量；
- 传感器安装位姿和图像分辨率；
- 基线定义和阈值；
- 指标公式；
- 每个随机种子对应的扰动时间表。

禁止根据单次失败临时增加房间、节点、UI或专用规则。发现缺陷时先登记为协议偏差，再决定是否统一重跑全部方法。

## 2. 研究问题

### RQ1：语义状态一致性

相较静态地图和即时覆盖策略，时序语义记忆能否降低过期对象比例，提高对象生命周期状态的准确性？

### RQ2：任务驱动更新效率

在相近任务成功率下，任务更新门控能否减少语义帧处理次数、记忆写入次数、GPU占用和能耗？

### RQ3：动态拓扑恢复

基于失败证据的边状态维护能否缩短临时阻塞后的恢复时间，并避免使用过期路线？

### RQ4：仿真到实机迁移

保持消息与状态接口不变时，RGB-D和定位后端替换是否能够维持方法的相对优势？

## 3. 方法与基线

### B0：Static Semantic Map

- 初次确认后对象位置和边状态不再更新；
- 不进行时间衰减；
- 导航失败只执行相同目标的常规重试。

用途：证明动态维护相对于静态语义地图的必要性。

### B1：Instant Reactive Update

- 所有检测帧均处理；
- 新观测立即覆盖旧位置和置信度；
- 无生命周期和证据累计；
- 一次失败立即将边标记为阻塞，一次成功立即恢复。

用途：证明“看到就覆盖”在遮挡、漏检和短期阻塞下容易产生错误更新。

### B2：Fixed-rate Temporal Memory

- 采用与本文相同的时间衰减、融合和生命周期；
- 固定2 Hz语义处理；
- 不使用任务相关性和失败突发频率。

用途：分离时序记忆与任务调度的贡献。

### B3：Task-aware Memory

- 使用任务相关更新门控；
- 使用idle/task两种频率；
- 不根据失败进入burst模式；
- 拓扑边不进行概率恢复。

用途：分离任务调度和失败恢复的贡献。

### Ours：Task- and Failure-aware Streaming Maintenance

- idle/task/burst三速率调度；
- 任务相关更新门控；
- 时间衰减与生命周期；
- 边阻塞概率、时间恢复和成功证据；
- 失败后从更新图重新规划。

## 4. 消融实验

| 名称 | 去除内容 | 验证问题 |
| --- | --- | --- |
| Ours-no-task | 任务相关项 \(R\) | 任务门控贡献 |
| Ours-no-novelty | 新颖性项 \(N\) | 新目标/迁移响应 |
| Ours-no-decay | 置信度时间衰减 | 陈旧记忆处理 |
| Ours-no-lifecycle | 离散生命周期 | 状态管理贡献 |
| Ours-no-burst | 失败突发感知 | 恢复延迟 |
| Ours-no-edge-recovery | 边时间恢复和成功证据 | 临时阻塞后的误封锁 |

主论文优先报告 `no-task`、`no-decay`、`no-burst`和`no-edge-recovery`，其余放附录，避免实验矩阵失控。

## 5. 场景矩阵

| 编号 | 功能场景 | 扰动 | 关键区分 | 主要指标 |
| --- | --- | --- | --- | --- |
| S1 | 配送/仓储 | 包裹从receiving迁移到storage | 旧位置失效 | update latency、target success |
| S2 | 装卸 | 推车暂时阻塞packing-loading | 临时而非永久阻塞 | recovery time、detour ratio |
| S3 | 巡检 | inspection-storage门关闭后重开 | 状态反转 | edge-state F1、false blocking time |
| S4 | 目标检索 | 目标短期遮挡后再次出现 | 遮挡而非迁移 | false removal、reobservation time |
| S5 | 配送 | 包裹永久移出可见区域 | 消失而非遮挡 | disappearance latency、search termination |
| S6 | 混合班次 | S1+S2+S3依次发生 | 多扰动长期运行 | mission success、memory growth |

v0.20已有S1、S2、S3和S6的扰动基础。S4和S5在接口审计完成前不纳入主结果，避免使用不严格的“未检测即消失”逻辑。

## 6. 扰动与感知因子

### 6.1 动态强度

- Low：每个任务最多1次环境变化；
- Medium：每个任务2–3次变化；
- High：变化间隔小于一次完整任务平均时长。

### 6.2 感知退化

- 漏检率：0、0.1、0.3；
- 处理延迟：0、100、300 ms；
- 深度噪声：按距离分段添加；
- 短期遮挡：2、5、10 s。

主实验只使用Medium动态强度和10%漏检。其余作为鲁棒性实验，禁止全部因素全排列。

### 6.3 计算预算

- 低预算：平均语义处理不超过1 Hz；
- 中预算：平均不超过2 Hz；
- 高预算：允许8 Hz短时burst，但总处理帧数受限。

预算应按整个任务的处理帧数或GPU时间定义，而不是只报告名义定时器频率。

## 7. 指标定义

### 7.1 语义状态指标

#### 更新延迟

\[
T_{update}=t_{memory\_correct}-t_{change\_truth}.
\]

`memory_correct`必须满足类别正确、区域正确、位置误差小于阈值，并持续至少两个评估周期。

#### 过期对象比例

\[
R_{stale}=\frac{\sum_t N_{active\_but\_invalid}(t)}
{\sum_t N_{active}(t)}.
\]

这里的stale是“在线仍作为有效对象但真值已失效”，不能直接使用算法内部的 `STALE` 标签代替。

#### 生命周期准确率

将真值事件转换为 `present`、`temporarily_occluded`、`relocated`、`absent`状态，与记忆生命周期对齐，报告macro-F1和混淆矩阵。

#### 位置误差

只对当前真值存在且在线未删除的匹配对象计算：

\[
E_p=\frac1N\sum_i\|\hat{\mathbf p}_i-\mathbf p_i^{gt}\|_2.
\]

#### 错误更新率

\[
R_{false\_update}=\frac{N_{wrong\_create}+N_{wrong\_relocate}+N_{wrong\_remove}}
{N_{all\_memory\_updates}}.
\]

### 7.2 拓扑指标

- edge-state macro-F1；
- 临时阻塞检测延迟；
- 道路恢复延迟；
- false blocking time：实际已恢复但在线仍不可通行的累计时间；
- false free time：实际阻塞但在线仍标记FREE的累计时间；
- graph revision precision：导致任务相关状态变化的版本更新比例。

### 7.3 导航指标

- Task Success Rate；
- Recovery Success Rate；
- Recovery Time：首次失败到重新产生有效运动的时间；
- Path Length；
- Detour Ratio：实际路径长度/扰动后最短可行路径；
- collision count和minimum clearance；
-无有效目标时的正确终止率。

### 7.4 系统指标

- 相机帧数、触发数、实际处理帧数；
- semantic processing ratio；
- 接受写入与 `task_deferred` 数量；
- 单帧处理时间P50/P95；
- 语义轨迹峰值与图节点峰值；
- Jetson GPU利用率、显存、功率和每任务能耗；
- 节点消息队列丢弃与过期帧数量。

## 8. 试验数量与随机化

### 8.1 仿真主实验

建议第一阶段：

\[
4\ scenarios\times5\ methods\times30\ seeds=600\ trials.
\]

若运行时间过长，先用10个种子完成预注册检查，不用于最终显著性结论；确认协议稳定后再扩展至30个种子。

每个随机种子固定：

- 扰动发生时间；
- 感知漏检序列；
- 初始对象微小位置扰动；
- 任务目标；
- 允许的计算预算。

不同方法必须共享相同种子，形成配对比较。

### 8.2 实机实验

选择S1、S2、S3，每种方法每场景重复5–10次。实机不承担大规模统计搜索，只验证：

- 消息接口可替换；
- 相对趋势与仿真一致；
- Orin Nano计算预算可满足；
- MID-360S与D435i下闭环能够完成。

## 9. 统计分析

- 成功率：报告比例、95%置信区间，并使用配对种子下的McNemar检验；
- 连续指标：先检查分布；非正态时使用配对Wilcoxon检验；
- 多方法比较：Friedman检验后进行校正的两两比较；
- 同时报告效应量，不只报告p值；
- 多重比较采用Holm校正；
- 报告所有失败试验，不删除“异常运行”，除非满足预注册的基础设施故障标准。

## 10. 单次试验流程

1. 设置 `trial_id`、method、scenario、seed；
2. 重置Gazebo实体、机器人位姿、语义记忆、动态图、调度器和指标器；
3. 等待传感器、TF和控制状态全部READY；
4. 发布结构化任务；
5. 开始记录ROS bag、JSONL和Jetson telemetry；
6. 按固定时间表注入扰动；
7. 达到成功、失败或超时终止条件；
8. 写出不可变的trial manifest和summary；
9. 自动检查真值泄漏、时间戳单调性和缺失消息；
10. 只有通过质量门控的试验进入统计表。

## 11. 试验有效性门控

单次试验满足以下任一条件应标记为基础设施无效，而不是算法失败：

- 仿真时间倒退或停顿超过阈值；
- RGB、Depth、CameraInfo或TF启动失败；
- 评测真值事件未成功执行；
- 日志文件损坏；
- 控制节点在任务开始前退出。

下列情况必须计为算法失败：

- 目标未找到；
- 更新过期状态导致错误导航；
- 临时阻塞后未能恢复；
- 算法超时；
- 因自身消息队列拥塞丢失关键证据。

## 12. 最小论文结果表

主文至少包含：

1. 各方法在S1–S4上的Task Success和Update Latency；
2. Stale Object Ratio、Lifecycle macro-F1；
3. Recovery Time、Detour Ratio和false blocking time；
4. 处理帧数、P95延迟、GPU功率；
5. 四个核心消融结果；
6. 仿真与实机的趋势对照；
7. 一张典型长期任务中的状态时间线。

