# Phase 2 LLM + Dynamic Graph MVP Acceptance

Date: 2026-07-19

Scope: dynamic semantic topology JSON, one-step OpenAI-compatible semantic
planning, evidence gate, graph update and online semantic replanning on top of
the existing `SEARCH_AND_NOTIFY` executor. This is not EGA-Nav, a metric path
planner, real visual recognition, or complete dynamic-obstacle avoidance.

## Implemented chain

`mission_text -> MissionSpec -> graph snapshot -> provider.plan() -> plan_gate
-> existing /task_goal navigation -> simulation observation -> graph update ->
PLAN_SEARCH`

The remote call runs in a worker thread. ROS callbacks, `/office_rpg/stop`, and
the existing zero-velocity safety chain remain responsive while the HTTP call
is pending. A provider exception, timeout, empty response, or invalid JSON is
recorded and immediately handed to the deterministic offline semantic planner.

## Graph JSON schema

The minimal graph contains only these semantic nodes:

- `lobby`
- `junction` (navigation compatibility name: `corridor_junction`)
- `room_904`
- `room_906`
- `room_908`

Each node has `id`, `type`, `searched`, and `reachable`. Each edge has `from`,
`to`, `state`, and semantic route `cost`. The remaining top-level fields are:

- `graph_revision`
- `robot_region`
- `entity_beliefs[{entity,candidates}]`
- `recent_events[]`
- `allowed_actions[]`

No graph or provider request contains NPC metric coordinates, Gazebo poses,
`cmd_vel`, or physical paths. `TARGET_NOT_FOUND` marks the region searched,
multiplies its belief by 0.05, normalizes all remaining candidates, appends the
event, and increments `graph_revision`. `EDGE_BLOCKED` is accepted through the
external dynamic-observation interface, marks the semantic target unreachable,
blocks its incident edges, increments the revision, and returns to planning.

## Remote API configuration

Configure the launch environment; never put the key in a source file, launch
file, YAML, UI field, or log:

```bash
export LLM_API_KEY='...'
export LLM_BASE_URL='https://api.deepseek.com'
export LLM_MODEL='deepseek-v4-flash'
export LLM_TIMEOUT_S='15'
```

The provider uses the OpenAI Python SDK with:

- `response_format={"type":"json_object"}`
- `extra_body={"thinking":{"type":"disabled"}}`
- `stream=False`
- no deprecated `deepseek-chat` or `deepseek-reasoner` model name

The API key is retained only inside the SDK client. Debug output contains the
provider name, model, base URL, timeout, latency, request JSON, response JSON,
and fallback reason, but never the key.

## System prompt

```text
You are the high-level semantic task planner for an indoor mobile robot.

You receive a mission and a dynamic semantic topological graph in JSON.
Select exactly one next semantic action.

Rules:
1. Output one JSON object only.
2. Never invent nodes, people, edges or actions.
3. Use only values listed in allowed_actions.
4. target_region must be an existing graph node.
5. Do not output coordinates, paths, velocities or ROS commands.
6. Prefer unsearched reachable regions with stronger target belief.
7. If the previous region returned TARGET_NOT_FOUND, choose another region.
8. If no valid region exists, output ABORT_TASK.
9. A* and the robot navigation system will calculate the physical route.
```

## Plan gate

The gate accepts exactly these fields: `graph_revision`, `action`,
`target_region`, `target_entity`, `reason_code`, and `fallback_region`.
It rejects stale revisions, unknown actions/fields/nodes/entities, unreachable
targets, and coordinate/path/velocity/ROS-command fields. Rejection never
executes the remote output; the executor records the reason and validates a new
offline decision against the same current graph.

## Actual checks performed

### Runtime passed

- Existing Gazebo corridor, Ranger model, NPC schedule, mission manager,
  search executor, perception stub, and original semantic safety chain launched
  together.
- Offline end-to-end search produced a first region observation, graph update,
  a second planning decision, target confirmation, and reminder completion.
  A recorded run showed graph revisions 1 -> 3 -> 5 and retained
  `TARGET_NOT_FOUND` / `TARGET_DETECTED` in `recent_events`.
- An additional no-key run completed `SEARCH_AND_NOTIFY` in `room_906` with
  `identity_confirmed=true`, `truth_access=NONE`, and a valid gate decision.
- The ordinary ROS topic list contained no `/scan` and no
  `pointcloud_to_laserscan` node during Office RPG execution.
- Streamlit served successfully on port 8502 (`/_stcore/health = ok`). The
  Streamlit test runner constructed the page with no exception and found all
  three requested panels: graph JSON, API input/output JSON, and gate/revision.
- The RGB-D guard added after an observed collision received real `32FC1`
  `/camera/depth_image` frames. A completed search run measured a minimum
  robot-to-NPC centre distance of 0.904 m. Using a conservative Ranger envelope
  radius of 0.446 m and NPC radius of 0.20 m, minimum envelope clearance was
  0.258 m and `overlap_samples=0`. Ground truth was read only by the separate
  acceptance monitor, never by online control.
- Ctrl-C stopped the test launch and Streamlit; no validation process was
  intentionally left running.

### Static/unit checks passed

- Python compilation for package and UI modules.
- shell syntax, SDF XML parsing, and YAML parsing.
- Deterministic graph test: `room_904`, `TARGET_NOT_FOUND`, revision increment,
  normalized belief update, then `room_906`.
- Illegal `room_999` test: rejected as `TARGET_REGION_UNKNOWN`; it was not
  dispatched to `/task_goal`.
- OpenAI-compatible payload test: JSON output mode, disabled thinking, flash
  model, non-streaming response, parsed JSON object, and no key in debug data.
- Provider request serialization contains no `x`, `cmd_vel`, or NPC truth key.

### Not passed / blocked

- A real DeepSeek network call was **not verified in this acceptance run**.
  `LLM_API_KEY` was not visible in the execution environment used by the
  acceptance process, even though it may be exported in another terminal.
  No claim of a real API call is made. Start the demo from the same shell that
  exports the four `LLM_*` variables and check `api_called=true` plus
  `remote_success=true` in `/office_rpg/llm_planner_debug`.
- The runtime illegal-output injection run was interrupted after a visual
  collision was observed. The same rejection/fallback path passed deterministic
  gate tests, but is not labelled as a completed runtime acceptance.
- A reverse retask from the 906 area back to 904 can stop after turning when the
  existing semantic local controller produces zero output. The safety boundary
  does not push through the NPC. Full route recovery remains incomplete.

## Collision limitation

NPCs now have compact cylinder collision geometry, start away from Ranger and
observation points, and the most direct junction conflict was moved away from
the 906 route. The Office RPG watchdog also applies a small sensor-only RGB-D
forward protection zone: consecutive near-depth frames suppress all translation;
a pure in-place retask rotation may turn away, and translation resumes only
after clear frames. It never subscribes to NPC pose, schedule, perception truth,
or Gazebo entity coordinates.

This is deliberately a minimum MVP repair, **not** complete dynamic avoidance.
It has no 360-degree coverage, PointCloud2/VoxelLayer integration, social
navigation, contact-aware recovery, or alternate metric-route planner.

## UI debug topics

- `/office_rpg/topology_graph`
- `/office_rpg/llm_planner_debug`
- `/office_rpg/plan_gate_result`

The normal UI continues to hide undiscovered NPC truth. Developer truth mode is
display-only and does not change graph content, provider input, gate output, or
search order.

## One-command start

```bash
source /opt/ros/humble/setup.bash
source /home/zbx/ranger_ws/install/setup.bash
bash /home/zbx/ranger_ws/src/rangermini_doorway_sim/scripts/start_office_rpg_demo.sh \
  use_llm:=true llm_provider:=deepseek_v4_flash
```

Frontend: `http://localhost:8502`

## Explicitly not implemented

- Complex EGA evidence alignment, suffix repair, or probability calibration
- Real D435i person detector / face recognition
- Real MID360S navigation, FAST-LIO, PointCloud2 VoxelLayer, or full 3D safety
- True Nav2 alternate-route execution for `EDGE_BLOCKED`
- Real robot hardware control

