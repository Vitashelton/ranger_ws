# v0.20实验接口缺口审计

## 结论

v0.20已经能够作为算法原型底座，但尚不能直接生成论文级消融结论。当前最重要的工作不是增加场景，而是补齐“同一代码切换基线、可重复复位、真值对齐评估、统一时间基准和Nav2结果反馈”五类实验接口。

以下分为P0、P1和P2。P0未完成前不建议启动大规模实验。

## P0：正式实验前必须完成

### P0-1 统一试验上下文

缺少统一的 `TrialContext`：

```json
{
  "trial_id": "S2_B3_seed017",
  "method": "task_aware",
  "scenario": "cart_blockage",
  "seed": 17,
  "start_stamp": 0.0,
  "time_budget_sec": 180.0,
  "compute_budget": {"semantic_frames": 240}
}
```

要求：每条观测、记忆事件、图事件、导航结果和真值事件都携带 `trial_id`。没有该字段，离线脚本容易混合不同运行的数据。

### P0-2 全系统确定性复位

当前 `/benchmark/reset`主要复位扰动时钟和实体，但还需要统一复位：

- 机器人位姿和速度；
- 语义记忆轨迹与计数器；
- 动态图概率和版本号；
- 调度器任务、burst状态和统计量；
- 控制器路径、阻塞计时与当前区域；
- 指标器文件和trial manifest；
- 随机数生成器。

建议提供 `/benchmark/reset_trial`服务，只有所有节点返回READY后才允许发布任务。

### P0-3 单代码路径基线切换

目前各基线主要存在于实验设计中，缺少统一运行参数。需要：

```yaml
method_mode: static | instant | fixed_temporal | task_aware | full
```

同一份节点代码根据配置关闭某个机制，禁止为每个基线复制一套节点，否则容易产生与算法无关的实现差异。

### P0-4 统一ROS/仿真时间

当前扰动管理器使用 `/clock`，而调度、记忆衰减和边恢复大量使用 `time.monotonic()`。在Gazebo暂停、低于实时速度或bag回放时，两套时间会分离。

必须统一使用ROS clock：

- 算法状态时间：`node.get_clock().now()`；
- 传感器证据时间：消息header stamp；
- 计算耗时：允许使用monotonic/perf_counter，但不能用于语义衰减；
- 日志同时保留sim stamp和wall stamp。

这是P0问题，因为它会直接改变更新延迟和生命周期结果。

### P0-5 真值匹配评估器

当前metrics主要记录消息数量，还没有计算：

- 在线轨迹与真值实体的数据关联；
- update latency；
- stale object ratio；
- lifecycle macro-F1；
- false free/false blocked time；
- 扰动后最短可行路径。

需要新增独立的offline evaluator。该评估器可以读取真值，但输出不得反馈给在线算法。

### P0-6 显式负证据与可见域

当前“没有检测到目标”主要通过时间衰减体现，尚不能严谨区分：

- 目标不在相机视场；
- 目标被遮挡；
- 目标确实消失；
- 检测器漏检。

感知输出需要增加：

```json
{
  "observation_frustum": {...},
  "visible_regions": ["storage"],
  "frame_complete": true,
  "negative_categories": ["parcel_red"]
}
```

只有当历史目标预计位于本次可靠可见域内，且传感器帧完整时，未检测才能作为负证据。S4遮挡和S5消失实验依赖此接口。

### P0-7 结构化失败分类

当前主要失败是 `PATH_BLOCKED`。需要固定枚举：

```text
PATH_BLOCKED
PLANNER_FAILED
CONTROLLER_STUCK
GOAL_REACHED_UNCONFIRMED
TARGET_MEMORY_STALE
PERCEPTION_TIMEOUT
LOCALIZATION_UNCERTAIN
```

每个失败包含 `source`、`confidence`、`edge/region/object`、持续时间和证据摘要。恢复策略不能从自由文本推断失败类型。

### P0-8 Nav2适配器

仿真控制器适合smoke test，但论文闭环需要Nav2 action反馈接口：

- `NavigateToPose` goal/cancel/result；
- planner和controller错误码；
- recovery行为开始与结束；
- 实际路径和控制耗时；
- 将Nav2失败转换为P0-7结构化事件。

本文算法不修改Nav2内部规划器，只消费其结果并维护语义状态。

## P1：主实验前应完成

### P1-1 场景参数化与种子

扰动事件已经YAML化，但漏检、深度噪声、遮挡持续时间和处理延迟仍需由同一seed产生。需要输出不可变的trial manifest，记录配置文件哈希。

### P1-2 感知队列与过期帧策略

当前触发器可能在上一帧仍在处理时继续触发。应显式记录：

- queue depth；
- dropped trigger；
- stale frame drop；
- trigger-to-result latency；
- 是否允许并行推理。

Orin Nano实验中，过期帧丢弃策略本身会影响闭环效果。

### P1-3 资源遥测

需要独立记录Jetson：

- `tegrastats`时间序列；
- GPU/CPU利用率；
- 显存和系统内存；
- 模块功率；
- 当前功耗模式与时钟配置；
- TensorRT engine、精度模式和输入尺寸。

资源日志必须与ROS时间对齐。

### P1-4 参数快照和版本信息

每次试验保存：

- Git commit或源代码SHA256；
- ROS发行版；
- Gazebo版本；
- 模型engine哈希；
- 所有ROS参数；
- 硬件功耗模式；
- 场景YAML哈希。

### P1-5 类型化消息或严格JSON Schema

当前JSON字符串便于迭代，但正式实验至少需要JSON Schema校验，禁止缺字段静默回退。长期建议定义：

- `SemanticObservation`；
- `MemoryTrack`；
- `TopologyEdgeState`；
- `FailureEvidence`；
- `TrialContext`。

### P1-6 图查询和路径记录

需要记录每次重规划时：

- 输入图revision；
- 候选路线；
- 被排除边及原因；
- 选择路线及总代价；
- 任务相关对象快照。

否则无法解释恢复成功来自图更新还是控制器偶然绕行。

### P1-7 实验质量门控

自动检查：

- online节点是否订阅真值命名空间；
- 传感器和TF是否READY；
- 时间戳是否单调；
- 扰动是否真正执行；
- summary与bag是否完整；
- 每个trial是否只有一个终止状态。

## P2：实机论文结果前完成

### P2-1 D435i TensorRT后端

保留 `/semantic_observations`协议，增加真实检测器版本、类别表、阈值和标定信息。颜色后端只用于仿真。

### P2-2 MID-360S定位与代价地图

固定：

- `base_link -> livox_frame`外参；
- 点云时间同步；
- FAST-LIO或所选定位输出；
- 地面/高度过滤；
- Nav2 obstacle/voxel layer配置。

### P2-3 实机扰动记录

真实实验不能依赖Gazebo事件，需要操作员按协议移动包裹、推车和门，并通过独立按钮或视频标注记录扰动时间。该时间只进入评估，不反馈算法。

### P2-4 安全与终止接口

保留硬件急停、cmd_vel watchdog、速度限制和独立碰撞监控。算法失败不得绕过底盘安全层。

## 明确不做

以下工作不属于当前论文收敛阶段：

- 新增酒店、医院或更多楼层；
- 增加更复杂Web UI；
- 将LLM接入低层控制；
- 训练生成式世界模型；
- 重做Ranger Mini转向动力学；
- 同时研究人脸识别、社会导航和多机器人协作。

## 推荐实施顺序

1. P0-4统一时间；
2. P0-1和P0-2试验上下文与全复位；
3. P0-3基线模式；
4. P0-5真值评估器；
5. P0-6负证据；
6. P0-7和P0-8失败/Nav2接口；
7. P1实验记录与资源遥测；
8. 先跑10个种子的预注册检查；
9. 冻结参数后运行正式30种子实验；
10. 最后进行实机替换验证。

