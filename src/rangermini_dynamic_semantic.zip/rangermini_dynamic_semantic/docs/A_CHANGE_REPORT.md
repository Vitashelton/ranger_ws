# Change Set A Report

## Result

Change Set A establishes the experiment-time determinism boundary for the v0.20.0 paper-freeze baseline. It adds explicit trial/task conditions and removes wall-clock time from experiment state logic without changing the frozen algorithms, scenarios, or research claims.

## Modified files

| File | Change |
|---|---|
| `launch/dynamic_semantic_benchmark.launch.py` | Common trial parameters, task input, `use_sim_time` propagation |
| `config/task_context.yaml` | Default non-LLM task contract |
| `rangermini_doorway_sim/streaming_perception_scheduler.py` | ROS-time scheduling; canonical TaskContext producer |
| `rangermini_doorway_sim/rgbd_semantic_perception.py` | Trial context propagation; ROS event timestamps |
| `rangermini_doorway_sim/temporal_semantic_memory.py` | ROS-time lifecycle logic; \(q_t\) consumption |
| `rangermini_doorway_sim/dynamic_topology_maintenance.py` | ROS-time edge state and recovery timing |
| `rangermini_doorway_sim/benchmark_navigation_controller.py` | ROS-time smoke-controller timeout and navigation events |
| `rangermini_doorway_sim/dynamic_scene_manager.py` | `/clock`-only scenario progress and oracle timestamps |
| `rangermini_doorway_sim/dynamic_benchmark_metrics.py` | ROS-time JSONL rows and trial metadata |
| `test/test_change_set_a_contract.py` | Static invariants for time, launch, context, and task flow |
| `docs/*.md` | Freeze, audit, change log, and this report |

## New interfaces

### TrialContext

Every dynamic benchmark event carries:

```json
{
  "trial_id": "trial_S6_007",
  "scenario_id": "S6",
  "seed": 7,
  "method_mode": "Ours",
  "task_context": {}
}
```

The launch arguments are `trial_id`, `scenario_id`, `seed`, `method_mode`, `task_context_file`, and `task_context_json`.

`method_mode` is validated as one of `B0`, `B1`, `B2`, `B3`, or `Ours`, but Change Set A deliberately does not implement baseline behavior switching.

### TaskContext / \(q_t\)

Task input supports either a YAML file or an inline JSON object with:

```json
{
  "task_id": "delivery_001",
  "task_type": "delivery",
  "target": "parcel_red",
  "target_region": "storage",
  "priority_objects": ["parcel_red", "free_path"],
  "failure_policy": "reroute"
}
```

The scheduler validates and publishes this contract on the transient-local `/task_context/current` topic. Semantic memory consumes it in its relevance calculation, making \(q_t\) an explicit input to the recursive state update. No LLM is involved.

### Time contract

- Experiment state, lifecycle, scheduler, failure timeout, topology, oracle, and event timestamps use ROS clock time.
- Launch defaults `use_sim_time:=true` and propagates it to all seven dynamic benchmark nodes plus the odometry adapter.
- `require_sim_time:=true` causes the dynamic nodes to reject a launch with simulation time disabled.
- `time.perf_counter()` remains only around a single RGB-D perception computation and is not used to advance experiment state.

## Preserved invariants

- The frozen title direction and three mechanisms are unchanged.
- The estimator remains \(X_t=F(X_{t-1},Z_t,q_t,f_t)\); no Bayesian-posterior claim was introduced.
- `dynamic_benchmark.yaml`, the SDF world, method section, and experiment protocol retain their pre-change SHA-256 values recorded in `PAPER_FREEZE.md`.
- No scenario, semantic update formula, lifecycle threshold, topology formula, contribution, online perception source, or navigation backend was added or redesigned.
- Gazebo truth remains outside the online semantic observation path. Change Set A only timestamps and labels its oracle events.

## Acceptance results

| Check | Result | Evidence |
|---|---|---|
| Python compilation | PASS | `python3 -m compileall` |
| Existing static tests | PASS | 4 tests |
| Change Set A contract tests | PASS | 6 tests |
| No wall clock in state modules | PASS | AST scan for `time.time`, `time.monotonic`, `perf_counter` |
| `perf_counter` only for perception duration | PASS | exactly two bracketing calls in RGB-D perception |
| Sim-time launch propagation | PASS | launch contract test |
| TaskContext reaches memory relevance update | PASS | contract/path test |
| All dynamic JSON event sources carry TrialContext | PASS | source contract test |
| Gazebo pause/resume runtime test | NOT RUN | ROS 2 and Gazebo executables are unavailable in this build environment |

The static pause invariant is satisfied: lifecycle, scheduler, topology decay, and controller timeout derive elapsed time only from ROS time, so a paused `/clock` cannot advance them. This is not presented as a substitute for the pending target-machine runtime test.

## Explicitly deferred

Change Sets B/C/D, experiment reset, executable baseline policies, Nav2, offline evaluator, and the 10-seed pilot were not implemented or run.
