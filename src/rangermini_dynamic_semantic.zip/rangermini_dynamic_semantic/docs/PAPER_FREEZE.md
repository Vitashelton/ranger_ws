# v0.20.0 Paper Freeze

Freeze basis: `rangermini_dynamic_semantic_benchmark v0.20.0`.

## Research scope

Working title:

> Streaming Semantic State Maintenance Framework for Task-driven Navigation of Mobile Robots in Dynamic Indoor Environments

The implementation is positioned as an **Active Semantic State Estimator / Recursive Semantic State Estimator**:

\[
X_t = F(X_{t-1}, Z_t, q_t, f_t)
\]

It does not claim Bayesian posterior inference.

The three frozen mechanisms are:

1. Task-aware Semantic State Update
2. Temporal Evidence Fusion and Lifecycle Estimation
3. Dynamic Topology Maintenance with Failure Recovery

## Change control

Change Set A is limited to experiment-time determinism, `TrialContext`, and the non-LLM `TaskContext` contract. It must not change the problem definition, add algorithm modules, add benchmark scenarios, add contribution claims, connect Nav2, implement baseline switching, or run the pilot experiment.

Change Set B is limited to atomic trial reset and reset verification infrastructure. It may clear runtime state, restore the frozen Gazebo fixture, rotate trial logs, and expose reset acknowledgements, but it must not alter algorithm formulas, scenario content, baseline behavior, Nav2 integration, evaluation metrics, or the pilot protocol.

Frozen assets retained by Change Set A:

| Asset | SHA-256 |
|---|---|
| `config/dynamic_benchmark.yaml` | `e4ce3fe9a63651b7044c4fb85ae6e412cbf2790fa8135465ac4b5f1809e65ea7` |
| `worlds/dynamic_indoor_benchmark.sdf` | `ee3c673ba72ef91f4e695e12e826fec6df0784bc683b96553f13f170bbed762d` |
| `docs/PAPER_METHOD_SECTION_ZH.md` | `c3471e2bf45e8d86d36e07538430a8d94d7b7e9e3e57f5587336da2e94f64349` |
| `docs/EXPERIMENT_PROTOCOL_V020_ZH.md` | `89dfcaa6af29999e30126002ff60f67f8babb726ca20faf64a351331a2937f36` |
