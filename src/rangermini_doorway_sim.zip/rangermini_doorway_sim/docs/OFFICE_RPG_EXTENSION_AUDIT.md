# Office RPG 增量扩展审计（Phase 0）

审计日期：2026-07-19（Asia/Shanghai）

审计范围仅为现有工作区和包：

```text
/home/zbx/ranger_ws
└── src/rangermini_doorway_sim
```

本次明确不新建 ROS 工作区、不重建 Ranger、不重建走廊世界、不另建 Nav2 基础设施。

## 审计基线与用户修改保护

修改前已执行：

```bash
git status --short
git log --oneline -10
find . -maxdepth 3 -type f | sort
```

HEAD 为 `3a4e04f 修复传感器`。工作区在本次开始前已经是显著 dirty 状态：本包包含大量 `A/AM/AD/??` 文件，相邻 `ranger_nav`、`ranger_sensor_fusion`、`fast_lio`、`vikit` 等也存在修改、删除或未跟踪内容。它们被视为用户资产；本次没有执行 reset、checkout、clean、仓库删除、commit、push 或强推，也没有恢复相邻包的删除项。

本包开始前尤其已有修改：

- `worlds/corridor_902_904_906_908.sdf`、`launch/corridor_semantic_benchmark.launch.py`；
- `setup.py`、`package.xml`、`config/corridor_semantic_params.yaml`；
- 语义 detector、memory、filter、markers、human command generator；
- 新增但未跟踪的 MID360、odom adapter、task landmark 和 watchdog 文件；
- 多个历史 closed-loop/topology 脚本在索引中表现为 `AD`，工作树实体已不存在。

## 直接复用项

- Gazebo Fortress 世界：`worlds/corridor_902_904_906_908.sdf`。
- Ranger Mini 2.0 导航级模型：模型名 `rangermini_2_0`，真实 footprint、可视轮组、VelocityControl、PosePublisher。
- 现有空间：902/904/906/908 房间块、门口、完整 `x=[0,22]` 走廊、S1/S2/S3 障碍。
- 可达门前目标：904 `(8.0,4.15)`、906 `(13.35,4.15)`、908 `(18.55,4.15)`。
- 现有运行时切换：`/task_goal` 支持 902/904/906/908，`/task_control` 支持 START/STOP。
- 现有语义链：detector stub → `/semantic_detections_json` → semantic memory → `/semantic_target_pose`。
- 现有 route-aware shared-control filter：房间重定向、绕障路径、目标在车后时 stop-and-spin、运行时 replanning。
- 现有安全链：`/cmd_vel_safe_raw` → `cmd_vel_watchdog` → `/cmd_vel_safe` → Gazebo Ranger。
- 现有 RViz：`rviz/corridor_semantic.rviz`；现有 CSV/metrics/benchmark 文档与脚本。
- 现有 `/odom` 统一契约：Gazebo model pose 经 `gazebo_odom_adapter` 转换并发布 TF。
- 现有 `/livox/lidar` PointCloud2 硬件接口位于 `launch/ranger_mid360s.launch.py`。

## 需要扩展项

- 在同一 SDF 内增加三个有颜色标记的 NPC，不改变走廊、门、障碍或 Ranger。
- YAML 日程、预定义可通行路径、Gazebo `set_pose` 调度。
- Gazebo 真值隔离的 `sim_perception_adapter` 和事件触发检测接口。
- Office RPG mission facade、状态/事件/NPC/区域/提醒 ROS JSON 接口。
- 统一 `LLMProvider.parse_mission()` 边界和可用的 Offline provider。
- Streamlit 单例 ROS bridge、任务按钮、Plotly 俯视图、状态和时间线。
- Office RPG launch 和可清理子进程的一键脚本。
- 旧 MID360 转 LaserScan 节点的默认关闭开关。

## 禁止修改项

- 不新建 `ranger_office_rpg_ws` 或任何新 ROS 工作区。
- 不替换 `rangermini_2_0` 模型，不修改底盘动力学论文口径。
- 不重建或替换走廊、904/906/908、门和障碍布局。
- 不删除现有 `/task_goal`、`/task_control`、语义 memory/filter、STOP、验收/日志入口。
- 不让 Streamlit 或 LLM 发布 `/cmd_vel`。
- 不提交 API Key，不在 UI 显示 Key 内容。
- 不把 FAST-LIO、完整 3D Nav2、人脸识别或远程 DeepSeek 写成 Phase 1 完成。

## 修改前实际能运行的闭环

```text
/task_goal + /task_control
  → corridor_human_command_generator
  → corridor_semantic_filter（语义目标、route-aware 重规划、避障）
  → cmd_vel_watchdog
  → /cmd_vel_safe
  → Gazebo rangermini_2_0
  → model pose
  → /odom + odom→base_link
```

它是现有自定义局部共享控制闭环，不是完整 Nav2 action 闭环。`README.md` 提到 Nav2 可作为后续消费者，但本包当前 benchmark launch 未启动 Nav2 server。

修改前还发现两个语义 Python 文件首行有孤立 `\`，会触发语法错误；Phase 1 仅删除这些无效字符，没有改变控制逻辑。

## MID360S 与旧 LaserScan 审计

- 旧 SDF 的 `mid360s_proxy` 是 Gazebo `gpu_lidar`，topic 为 `/scan`。
- 旧 `corridor_semantic_benchmark.launch.py` 会桥接 `/scan`。
- `ranger_mid360s.launch.py` 原本无条件启动 `pointcloud_to_laserscan`，输入 `/livox/lidar`，输出 `/scan`。
- `package.xml` 已有 `pointcloud_to_laserscan` runtime dependency。
- 本次不直接删除旧接口；给 MID360 launch 增加 `use_pointcloud_to_laserscan`，默认 `false`。
- 新 `office_rpg_demo.launch.py` 不桥接 `/scan`、不启动转换器、声明该参数默认 `false`。
- 本阶段没有宣称 PointCloud2 + VoxelLayer 的 3D Nav2 已接通。

## 修改前缺失项

- NPC 实体与日程；找人/提醒任务数据模型；人员视觉触发接口。
- `/office_rpg/*` 输入、服务和 JSON 状态话题。
- Streamlit UI 与持久 ROS bridge。
- provider 抽象、Offline parser、DeepSeek 配置回退。
- Office RPG 一键启动与专用验收记录。

## 实施阶段

1. Phase 0：完成本文审计、确认复用和禁止修改边界。
2. Phase 1：同一世界增量 NPC/YAML、任务状态接口、simulation perception stub、Offline provider、Streamlit UI、一键启动和实际验收。
3. Phase 2（本次不实施）：完整候选区域搜索、到达触发视觉、身份确认、安全距离停车、提醒完成、真实 Local Qwen/DeepSeek、D435i 替换 stub、Nav2 PointCloud2/VoxelLayer 集成。
