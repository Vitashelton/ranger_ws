# EGA-OfficeNav Demo Design

## Goal

EGA-OfficeNav keeps the existing corridor world, rooms 904/906/908, semantic
route controller, `/task_control` STOP path, `/cmd_vel_safe` boundary and
one-command launch. It adds an online semantic graph, remote one-step planning,
an Evidence Gate, a repeatable moving-NPC story, and a supervisor-facing UI.

## Closed loop

`mission_text -> MissionSpec -> graph snapshot -> DeepSeek/offline planner ->
Evidence Gate -> existing semantic region navigation -> active observation ->
graph update -> replan -> notify -> patrol 908 -> report`

The planner request has exactly four top-level fields: `mission`,
`dynamic_graph`, `execution_history`, and `last_failure`. Neither the planner,
executor nor normal UI subscribes to `/office_rpg/sim/*`; metric coordinates and
NPC truth terminate inside simulation adapters.

## Dynamic graph

`GraphManager` owns `ega_office_nav.v1`. Nodes carry reachability, searched
state and last-observation time; edges carry `FREE/BLOCKED`, semantic cost and
evidence source; entity beliefs are normalized after every negative
observation. `TARGET_NOT_FOUND` marks the node searched, multiplies its target
belief by 0.05, renormalizes, appends a timestamped `local_perception` event,
increments `graph_revision`, and returns the executor to `PLAN_SEARCH`.

Example initial graph (abridged):

```json
{
  "schema_version": "ega_office_nav.v1",
  "graph_revision": 1,
  "robot": {"current_region": "lobby", "mission_state": "PLAN_SEARCH"},
  "nodes": [
    {"id": "room_904", "type": "room", "searched": false,
     "reachable": true, "last_observed": null}
  ],
  "edges": [
    {"from": "junction", "to": "room_904", "state": "FREE",
     "cost": 3.4, "evidence_source": "static_map"}
  ],
  "entity_beliefs": [
    {"entity_id": "teacher_zhang",
     "candidates": {"room_904": 0.70, "room_906": 0.20, "lobby": 0.10},
     "last_seen": null}
  ],
  "recent_events": [],
  "allowed_actions": ["SEARCH_REGION", "NOTIFY_PERSON", "PATROL_REGION",
    "WAIT", "COMPLETE_TASK", "ABORT_TASK"]
}
```

## Remote planner and Evidence Gate

The OpenAI-compatible client reads only `DEEPSEEK_API_KEY`, `LLM_BASE_URL`,
`LLM_MODEL`, and `LLM_TIMEOUT_S`. It uses a non-streaming JSON response on a
worker thread. The API key is never included in status, events, logs or UI.
Timeout, connection failure, empty response and invalid JSON all enter the same
offline fallback path.

The Gate rejects stale revisions, unknown actions/nodes/entities, unreachable
nodes, already searched empty regions, extra fields and control/coordinate/ROS
content. A rejected remote plan is retained for display and a separately gated
Offline decision becomes the only executable decision.

## Safety boundary

The repeatable NPC scheduler uses seed 17. A simulation sensor adapter samples
anonymous NPC cylinder surfaces into `/office_rpg/npc_pointcloud`
(`sensor_msgs/PointCloud2`, `base_link`). `cmd_vel_watchdog` consumes only this
point cloud, never entity state or Gazebo coordinates. Points inside the forward
3-D protection box immediately force `/cmd_vel_safe` translation to zero; clear
frames resume the unchanged upstream task. Missing cloud data is a fail-safe
stop and explicit STOP has highest priority.

`office_rpg_safety_metrics` is an audit-only node. It may read simulation truth,
publishes minimum Ranger/NPC clearance and collision count, and has no connection
to planning, control or safety decisions.

## UI and launch

The three-column Streamlit page contains task/provider/STOP/reset/hallucination
controls, the live semantic topology, and state/API/Gate/report/safety evidence.
Developer truth is opt-in and marked `SIMULATION GROUND TRUTH — NOT AVAILABLE TO
PLANNER`.

Launch with:

```bash
export DEEPSEEK_API_KEY='...'
export LLM_BASE_URL='https://api.deepseek.com'
export LLM_MODEL='deepseek-v4-flash'
export LLM_TIMEOUT_S='15'
bash src/rangermini_doorway_sim/scripts/start_ega_office_nav_demo.sh
```

Without `DEEPSEEK_API_KEY`, the same command starts Offline mode.
