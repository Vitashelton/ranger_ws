#!/usr/bin/env bash
set -euo pipefail

workspace="${RANGER_WS:-/home/zbx/ranger_ws}"
port="${OFFICE_RPG_PORT:-8502}"
set +u
source /opt/ros/humble/setup.bash
if [[ -f "${workspace}/install/setup.bash" ]]; then
  source "${workspace}/install/setup.bash"
fi
set -u

# All demo participants run on this machine. A process-local Fast DDS fallback
# avoids stale host-specific CycloneDDS interface files without editing them.
if [[ "${OFFICE_RPG_LOCAL_DDS:-true}" == "true" ]]; then
  export RMW_IMPLEMENTATION=rmw_fastrtps_cpp
  unset CYCLONEDDS_URI || true
fi
export ROS_LOG_DIR="${ROS_LOG_DIR:-/tmp/office_rpg_ros_logs}"

children=()
cleanup() {
  trap - INT TERM EXIT
  for pid in "${children[@]}"; do
    kill -INT "${pid}" 2>/dev/null || true
  done
  wait 2>/dev/null || true
}
trap cleanup INT TERM EXIT

ros2 launch rangermini_doorway_sim office_rpg_demo.launch.py \
  launch_web_ui:=false use_pointcloud_to_laserscan:=false "$@" &
children+=("$!")

for _ in $(seq 1 40); do
  if ros2 service type /office_rpg/stop >/dev/null 2>&1; then
    break
  fi
  sleep 0.25
done

streamlit run "${workspace}/src/rangermini_doorway_sim/web_ui/app.py" \
  --server.port "${port}" --server.headless true &
children+=("$!")
echo "Frontend: http://localhost:${port}"
wait
