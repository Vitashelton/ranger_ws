# Changelog

## v0.20.0 + Change Set A + Change Set B

- Added the `RESET_REQUEST -> ACK -> READY` atomic reset barrier.
- Added reset acknowledgements and deterministic initial-state hashes for all seven runtime participants.
- Restored all mutable Gazebo entities and the RangerMini pose; published zero velocity during reset.
- Cleared RGB-D/odometry buffers, counters, semantic tracks, lifecycle revision, topology evidence, scheduler burst state, and smoke-controller state.
- Reset memory and graph revisions to zero and topology edge blocking probabilities to zero.
- Rotated JSONL/summary files per reset epoch and blocked logging before global `READY`.
- Added `/benchmark/reset_trial`, reset status/manifest topics, and an executable two-reset smoke verifier.
- Added Change Set B static and deterministic-contract tests.

No benchmark scenario, algorithm formula, baseline behavior, Nav2 integration, evaluator, metric definition, or pilot protocol was changed.

## v0.20.0 + Change Set A

- Added a common `TrialContext`: `trial_id`, `scenario_id`, `seed`, `method_mode`, and nested `task_context`.
- Added YAML/JSON `TaskContext` input and the canonical transient-local `/task_context/current` contract.
- Replaced wall-clock state logic with ROS clock time across the dynamic benchmark pipeline.
- Retained `perf_counter()` only around RGB-D perception computation for overhead measurement.
- Propagated `use_sim_time` and added fail-fast `require_sim_time` checks.
- Attached trial context to semantic, graph, navigation, scheduler, oracle, and metrics events.
- Added Change Set A static contract tests.

No benchmark scenario, algorithm formula, paper contribution, navigation backend, baseline behavior, reset mechanism, evaluator, or pilot protocol was changed.
