# EGA-OfficeNav Demo Acceptance

Date: 2026-07-20 (Asia/Shanghai). Workspace:
`/home/zbx/ranger_ws`. No hardware, commit, push, reset, checkout or clean was
used.

## Integrated run evidence

Final remote run mission `mission_1f995272` completed in Gazebo:

`PLAN_SEARCH -> room_904 -> TARGET_NOT_FOUND -> UPDATE_BELIEF -> PLAN_SEARCH ->
room_906 -> TARGET_DETECTED -> IDENTIFY_TARGET -> MESSAGE_DELIVERED -> room_908
-> GENERATE_REPORT -> COMPLETED`

- DeepSeek model: `deepseek-v4-flash`; calls: 2; latencies: 1.402 s, 1.691 s.
- First decision: `SEARCH_REGION room_904`, revision 1.
- After 904: belief `0.70/0.20/0.10` became
  `0.1044776/0.5970149/0.2985075`; searched=true; timestamped source event;
  revision became 3 (arrival is revision 2, negative evidence revision 3).
- Second decision: `SEARCH_REGION room_906`, revision 3.
- Final visited regions: `room_904`, `room_906`, `room_908`.
- Report: `message_delivered=true`, `visited_checkpoints=[room_908]`,
  `missed_checkpoints=[]`, `final_state=COMPLETED`.
- Safety: `yield_count=1`, minimum NPC clearance 0.287 m,
  `collision_count=0`, final safety state `STOPPED`.
- ROS graph contained `/camera/points` and `/office_rpg/npc_pointcloud`; it did
  not contain `/scan` or a pointcloud-to-laserscan node.

The last integrated API input contained only `mission`, `dynamic_graph`,
`execution_history`, `last_failure`; it included the searched 904 node and
timestamped negative-observation event. The returned JSON was:

```json
{"graph_revision":3,"action":"SEARCH_REGION","target_region":"room_906",
 "target_entity":"teacher_zhang","reason_code":"HIGHEST_VALID_BELIEF",
 "fallback_region":"lobby"}
```

An additional direct real-API capture recorded both complete exchanges. Call 1
(1.511 s) returned room_904 at revision 1; call 2 (1.401 s) received the updated
revision-2 graph and returned room_906. Response IDs were recorded without any
credential material.

## Hallucination evidence

The running ROS demo received an injected `target_region=room_999`. Gate output:

```json
{
  "result": "FALLBACK",
  "primary_result": {"result": "REJECT",
    "rejected_reason": "UNKNOWN_GRAPH_NODE"},
  "display": "REJECTED: UNKNOWN_GRAPH_NODE",
  "fallback_used": true,
  "final_decision": {"action": "SEARCH_REGION", "target_region": "room_904"}
}
```

No room_999 navigation goal was issued.

## Acceptance matrix

1. PASS — real DeepSeek API called in the integrated Gazebo run.
2. PASS — debug capture shows the full dynamic graph in the API request.
3. PASS — first remote decision was room_904.
4. PASS — odometry and `REGION_ARRIVED` prove physical travel to 904.
5. PASS — PointCloud2 gate yielded once; collision count remained zero.
6. PASS — active observation at 904 returned `TARGET_NOT_FOUND`.
7. PASS — searched state, belief and revision changed in the live graph.
8. PASS — second remote call chose room_906.
9. PASS — odometry and region arrival prove travel to 906.
10. PASS — teacher was confirmed and `MESSAGE_DELIVERED` emitted.
11. PASS — 908 was visited and report has no missed checkpoints.
12. PASS — live room_999 injection was rejected and Offline chose 904.
13. PASS — separate Offline Gazebo run completed the same mission.
14. PASS — STOP 0.2 s after submission returned `STOPPED`; planner futures are
    token-invalidated and navigation uses the same immediate STOP path.
15. PASS — planner request inspection contains no NPC world coordinates.
16. PASS — final integrated run: `collision_count=0`, minimum clearance 0.287 m.
17. PASS — runtime topic/node inspection found no `/scan` or conversion node.
18. PASS — legacy corridor launch remains present and independently launchable.
19. PASS — final cleanup check found no demo/Streamlit/Gazebo participant left.

## Known scope

The demo uses the existing navigation-level VelocityControl Ranger abstraction,
not real Ranger hardware or a complete Nav2 VoxelLayer. NPC perception and the
anonymous PointCloud2 sensor are explicitly simulation adapters; neither exposes
undiscovered world coordinates to the planner or normal UI.
