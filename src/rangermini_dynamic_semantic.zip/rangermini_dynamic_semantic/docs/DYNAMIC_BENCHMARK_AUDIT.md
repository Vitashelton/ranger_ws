# Dynamic benchmark audit and claim boundary

## Research claim

The v0.20 benchmark supports research on streaming semantic state maintenance
for task-driven navigation in dynamic indoor environments.  It does not claim
to be a Ranger steering-dynamics digital twin, a learned world model, an
open-vocabulary foundation model, or a complete real-robot Nav2 deployment.

## Corrected limitations from the corridor MVP

| Previous limitation | v0.20 correction |
| --- | --- |
| One straight corridor | 30 x 20 m multi-zone facility with an upper/lower loop |
| No useful alternative route | Eight-edge cyclic topology; blocked edges cause rerouting |
| Detector stub publishes configured objects | Detector consumes RGB, depth, CameraInfo and odometry |
| Semantic memory only keeps max confidence | Evidence fusion, time decay and explicit lifecycle |
| Fixed five-node graph | Configured place graph plus live semantic-object nodes |
| A blocked edge stays blocked forever | Probabilistic blockage with decay and success evidence |
| No compute-aware stream | Idle/task/burst perception rates and processing-ratio metrics |
| Dynamic changes mainly visual | Cart and door poses change collision geometry |
| Ground truth could be confused with perception | `/benchmark/ground_truth/*` is evaluation-only |

## Non-stub online data boundary

The following online nodes have no Gazebo truth subscription:

- `streaming_perception_scheduler`
- `rgbd_semantic_perception`
- `temporal_semantic_memory`
- `dynamic_topology_maintenance`
- `benchmark_navigation_controller`

The only node allowed to command scripted entity poses is
`dynamic_scene_manager`.  Its output namespace explicitly contains
`ground_truth` and is consumed by the logger, not the online policy.

The simulated detector uses configured object colours.  This is a genuine
image/depth measurement backend, but not a claim of general visual recognition.
The correct real-robot substitution is a D435i TensorRT detector that publishes
the same `/semantic_observations` schema.

## Dynamic state semantics

Object memory states:

```text
TENTATIVE -> CONFIRMED -> UNCERTAIN -> STALE -> REMOVED
                    ^          |
                    +-- REOBSERVED
```

Topological edge states:

```text
FREE -> SUSPECTED -> TEMP_BLOCKED
 ^                       |
 +-- successful traversal or temporal decay
```

Failures are evidence rather than irreversible map edits.  Repeated lidar
stops increase blockage probability; successful traversal reduces it; lack of
new evidence gradually relaxes a temporary block.

Memory writes are also task-gated.  Each observation receives an update
priority from task relevance, confidence, novelty and current staleness.
Low-value observations are counted as `task_deferred` instead of silently
consuming the same memory and compute budget as task-relevant evidence.

## Required paper baselines

1. Full-rate semantic processing.
2. Fixed low-rate semantic processing.
3. Change-triggered processing without task context.
4. Task-aware scheduling without failure bursts.
5. Proposed task- and failure-aware scheduling.
6. Proposed method without memory decay.
7. Proposed method without edge recovery.

Report task success, recovery success, path length, completion time, semantic
frames processed, processing ratio, stale-track ratio, false graph edits and
memory size.  On Jetson, add `tegrastats` power, GPU load and memory use.

## Remaining work before thesis-grade real-robot claims

- Replace Gazebo odometry with MID-360S localization/SLAM.
- Replace the benchmark controller with Nav2 action execution and recovery.
- Replace colour segmentation with a TensorRT detector on D435i frames.
- Calibrate `base_link -> camera` and `base_link -> livox_frame` transforms.
- Measure perception latency and power on the Orin Nano.
- Run repeated seeds in simulation and repeated physical-layout trials.
