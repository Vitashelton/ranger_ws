# Ranger Mini 2.0 + Mid-360S Hardware Contract

## Chassis interface

The simulation follows the ROS interface and motion-mode selection of the
`humble` branch of `agilexrobotics/ranger_ros2`:

- command: `/cmd_vel` (`geometry_msgs/msg/Twist`)
- odometry: `/odom` (`nav_msgs/msg/Odometry`)
- frames: `odom -> base_link`
- wheelbase: `0.494 m`
- track: `0.364 m`
- motion modes: dual Ackermann, parallel steering, spinning

The benchmark publishes safe velocity on `/cmd_vel_safe`. For the real robot,
remap that topic to the official base driver's `/cmd_vel`; do not run the
kinematic simulator and the CAN base driver at the same time.

```bash
ros2 run rangermini_doorway_sim cmd_vel_watchdog --ros-args \
  -p input_topic:=/cmd_vel_safe_raw \
  -p output_topic:=/cmd_vel
```

## Mid-360S boundary

Mid-360S is treated as a distinct sensor model. The checked-in configuration is
the actual installation: lidar `192.168.1.12`, host `192.168.1.5`, model type 8.
Files named `MID360_config.json` or launches named `msg_MID360.launch.py` are not
used as Mid-360S defaults.

The measured transform is `base_link -> livox_frame`: translation
`(0.30, 0.0, 0.70) m` and RPY `(0, 0.523599, 0) rad`.

```bash
ros2 launch rangermini_doorway_sim ranger_mid360s.launch.py
```

The `/scan` conversion transforms the cloud into `base_link` before applying
the height filter. Tune `scan_min_height` and `scan_max_height` from a bag rather
than widening them to the entire 3D cloud.

Before integrating with navigation, record:

```bash
ros2 pkg prefix livox_ros_driver2
ros2 topic list | grep -E 'livox|imu|point'
ros2 topic info -v /livox/lidar
ros2 topic info -v /livox/imu
```

Also preserve the exact Mid-360S JSON and launch file used on the Jetson. They
define the real topic names, frame id, data format and network endpoints.
