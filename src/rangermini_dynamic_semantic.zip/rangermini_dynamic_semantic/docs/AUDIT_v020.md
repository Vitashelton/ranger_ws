# v0.20.0 Pre-change Audit Record

The pre-change audit found that the frozen research direction was represented in code, but the experimental interface lacked deterministic time and explicit trial/task context.

| Frozen paper element | Pre-change implementation |
|---|---|
| Task-aware semantic update | `streaming_perception_scheduler.py`, `temporal_semantic_memory.py` |
| Temporal fusion and lifecycle estimation | `temporal_semantic_memory.py` |
| Dynamic topology and failure recovery | `dynamic_topology_maintenance.py`, `benchmark_navigation_controller.py` |
| Sensor-driven online observation | `rgbd_semantic_perception.py` |
| Simulator oracle boundary | `dynamic_scene_manager.py`, logged truth topics |

Change Set A addresses only these audited gaps:

- wall-clock-dependent state transitions and timeouts;
- incomplete `use_sim_time` propagation and enforcement;
- missing `TrialContext` on experiment events;
- no explicit producer or contract for task condition \(q_t\);
- no static contract tests for those invariants.

Reset orchestration, baseline configuration, Nav2 integration, unified paper logging, offline evaluation, and pilot trials remain outside Change Set A.

