# Change Set B Report

## Result

Change Set B adds an atomic trial-reset boundary to the v0.20.0 + Change Set A platform. A trial cannot enter `READY` until every configured runtime participant has restored its deterministic initial state and acknowledged the same `reset_id`.

The reset sequence is:

```text
RESET_REQUEST(reset_id, epoch, TrialContext)
    -> all participants stop advancing and clear state
    -> ACK(node, deterministic state hash)
    -> coordinator verifies the complete acknowledgement set
    -> READY(reset state hash)
    -> trial processing resumes
```

## Reset contract

| Participant | State restored before ACK |
|---|---|
| Gazebo fixture | All mutable benchmark entities at configured initial poses; robot at `(3, 10, 0.01, 0)`; zero velocity; event schedule cleared |
| RGB-D perception | RGB, depth, camera-info and odometry buffers empty; frame/processed/drop counters zero |
| Semantic memory | Tracks empty; next object ID reset; update counters zero; memory revision zero |
| Dynamic topology | Semantic nodes empty; graph revision zero; all edges `FREE`; blocking probabilities and traversal counters zero |
| Scheduler | Sequence and mode counters zero; stale/failure/burst state cleared |
| Smoke controller | Zero velocity; no goal/path/active edge/recovery state; controller edges restored |
| Logger | New epoch-specific JSONL and summary files; counters and cached events empty; recording disabled until global `READY` |

Gazebo simulation time is deliberately not rewound. Resetting `/clock` would violate Change Set A's monotonic simulation-time boundary and create ROS time-jump ambiguity. Instead, all mutable world entities are explicitly restored through Gazebo `SetEntityPose`, the robot is stopped and repositioned, and the scenario origin is restarted only after the global barrier reaches `READY`.

## Interfaces

| Interface | Purpose |
|---|---|
| `/benchmark/reset_trial` (`std_srvs/Trigger`) | Request the next reset epoch |
| `/benchmark/reset/request` | Transient-local reset request |
| `/benchmark/reset/ack` | Per-node acknowledgement and deterministic state hash |
| `/benchmark/reset/ready` | Global release barrier after all ACKs |
| `/benchmark/reset/status` | Current ACK/missing-node status |
| `/benchmark/trial_manifest` | Trial context, manifest hash and initial state hashes |

`expected_reset_nodes` is configurable for diagnostic launches that disable the scene manager or smoke controller. The default paper-freeze launch expects all seven participants.

## Deterministic signatures

Each ACK hashes only deterministic state; timestamps, reset epoch and reset ID are excluded. Therefore two resets of the same trial can directly compare:

- trial manifest hash;
- oracle schedule hash;
- initial semantic-memory state hash;
- initial topology state hash;
- memory and graph revisions;
- initial edge blocking probabilities.

The `atomic_reset_smoke` executable performs two successive service resets and writes `reset_smoke_report.json`.

Target-machine invocation after the benchmark is running:

```bash
ros2 run rangermini_doorway_sim atomic_reset_smoke
```

## Modified files

New reset infrastructure:

- `rangermini_doorway_sim/reset_contract.py`
- `rangermini_doorway_sim/reset_protocol.py`
- `rangermini_doorway_sim/trial_reset_coordinator.py`
- `rangermini_doorway_sim/atomic_reset_smoke.py`
- `test/test_change_set_b_contract.py`

Reset integration was added to:

- `dynamic_scene_manager.py`
- `streaming_perception_scheduler.py`
- `rgbd_semantic_perception.py`
- `temporal_semantic_memory.py`
- `dynamic_topology_maintenance.py`
- `benchmark_navigation_controller.py`
- `dynamic_benchmark_metrics.py`
- `launch/dynamic_semantic_benchmark.launch.py`
- `setup.py`

## Preserved invariants

- The paper title direction, problem definition, recursive estimator equation and three mechanisms are unchanged.
- No Bayesian-posterior claim was introduced.
- The world, scenario configuration, method section and experiment protocol retain their frozen SHA-256 hashes.
- Semantic fusion, lifecycle thresholds, task gate, topology evidence equations and failure recovery logic are unchanged.
- Gazebo truth remains isolated from online perception and policy modules.
- No baseline profile, Nav2 integration, offline evaluator, new scenario, new metric or pilot trial was added.

Memory revision is new experiment observability metadata. It increments when the existing memory state changes; it does not modify update acceptance, fusion or lifecycle behavior.

## Acceptance results

| Check | Result |
|---|---|
| Python compilation | PASS |
| Existing Change Set A and truth-isolation contracts | PASS, 10 tests |
| Change Set B reset contracts | PASS, 9 tests |
| Total static/contract tests | PASS, 19 tests |
| Two identical deterministic contract constructions | PASS; all four initial hashes equal |
| Frozen-asset SHA-256 verification | PASS |
| Wall-clock scan of reset infrastructure | PASS |
| ROS/Gazebo two-reset runtime smoke | NOT RUN in this container |

The runtime smoke was not claimed as passed because this build container has no `ros2`, `ign`, or `gz` executable. The delivered verifier makes that remaining target-machine acceptance explicit and machine-readable.

## Explicitly deferred

Baseline profiles, Nav2, offline evaluation, formal experiment logging schema expansion, and the 10-seed pilot remain outside Change Set B.
