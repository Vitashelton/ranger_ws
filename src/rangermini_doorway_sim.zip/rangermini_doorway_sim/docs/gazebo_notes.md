# Gazebo Fortress Notes

## Current v0.13 model

The main corridor launch uses a single rigid-body planar model controlled by
Gazebo `VelocityControl`. The model keeps the Ranger Mini 2.0 footprint and
sensor mounting, while wheel visuals have no collision or actuation role.

This is not a Mecanum model and not a high-fidelity 4WS model. Ranger Mini 2.0
mode conversion remains the responsibility of `ranger_ros2` on hardware.

Gazebo is used for repeatable navigation-level evaluation: world collision,
sensor topics, semantic events, dynamic obstacles, ground-truth pose and task
success. The previous physical floor coverage bug has been removed.

---

This package supports two levels:

## Level 1: ROS closed-loop benchmark

The robot is simulated by `kinematic_rangermini_sim.py`.
Gazebo is optional. This level is useful for quickly validating the safety-filter algorithm.

## Level 2: Gazebo world visualization

`worlds/narrow_doorway.sdf` opens a doorway benchmark in Gazebo Fortress.
The static robot visual is only a reference object. The actual simulated robot pose is published in ROS `/odom`.

## Why not full physics in v3?

RangerMini 2.0 is a four-wheel steering / omnidirectional platform. A faithful Gazebo physics model requires:
- accurate wheel steering geometry,
- wheel contact parameters,
- steering joint controllers,
- base driver interface,
- sensor plugin calibration.

For a thesis experiment, first validating the local risk and shared-control filter with a deterministic kinematic model is usually more stable. The full physics model can be inserted later by replacing `kinematic_rangermini_sim.py` with the real chassis driver or a Gazebo system plugin.
