# Office RPG Phase 1 验收记录

验收日期：2026-07-19（Asia/Shanghai）

验收构建：

```bash
cd /home/zbx/ranger_ws
colcon build --packages-select rangermini_doorway_sim --symlink-install
```

构建成功。由于主机当前全局 CycloneDDS 配置绑定已经不存在的 `192.168.3.231`，实际验收进程使用 `RMW_IMPLEMENTATION=rmw_fastrtps_cpp` 并临时 unset `CYCLONEDDS_URI`。一键脚本只在其子进程内默认采用相同 local DDS fallback，不修改全局配置。

## 真实运行通过

1. **现有世界和闭环启动**：除 Office launch 外，原 `corridor_semantic_benchmark.launch.py use_gazebo:=true launch_rviz:=false` 也已单独实际启动，Gazebo、旧 semantic/memory/filter、task landmark、watchdog、logger 和 odom adapter 均起来；Gazebo odom 报告初始 Ranger 世界坐标 `(1.20,2.30)`。
2. **Ranger 模型仍存在**：Gazebo `ign model --list` 包含 `rangermini_2_0`。
3. **904/906/908 与 STOP 未破坏**：Offline parser 三个目标均通过；UI 点击“去906”后状态为 `NAVIGATING`，Ranger 从 `(1.2,2.3)` 实际移动到走廊内；stop 服务返回 success 并切为 `STOPPED`，现有 filter/human generator 收到 STOP。
4. **三个 NPC 出现在现有场景**：Gazebo 实体列表包含 `teacher_zhang`、`student_li`、`visitor`，以及原有 Ranger、房间、门和障碍。
5. **YAML 日程移动**：在 `t≈57s` 张老师位于 `(8.0,4.15)`；跨过 60 秒后 `t≈86.8s` 处于 `room_904_to_room_906`，日程期望约 `(12.74,3.96)`，Gazebo 实测约 `(12.78,3.97)`；李同学在 80 秒后位于 `corridor_junction (11.0,3.75)`。
6. **Streamlit 8502**：`/_stcore/health` 返回 `ok`；无头 Chrome 完整渲染标题、三栏、俯视图、按钮和任务状态。访问地址为 `http://localhost:8502`。
7. **点击“去906”发布任务**：Streamlit 官方 AppTest 实际点击按钮，ROS 状态收到 `input_text=去906`、`target_region=room_906`、`current_action=navigate_to_room_906`。
8. **自定义文本发送**：AppTest 输入并发送“找李同学，提醒他提交报告”，任务解析为 `find_person_and_remind`，候选为 `room_908/corridor_junction`。
9. **停止按钮调用服务**：AppTest 实际点击“停止任务”，最终状态为 `STOPPED`，路径清空。
10. **任务状态实时输出**：`/office_rpg/mission_status` 按 2 Hz 输出 JSON，UI 显示任务字段。
11. **NPC 状态实时输出**：`/office_rpg/npc_states` 输出三个身份、区域、活动、日程、可见性、置信度和 Gazebo 世界坐标。
12. **事件接口/时间线**：任务管理器发布接收、解析、开始导航、停止、fallback 等 `/office_rpg/event_log` JSON；UI 保留最近 100 条并显示最近 15 条。
13. **事件触发视觉**：向 lobby 发出 trigger 后，simulation stub 返回 visitor 检测，置信度 `0.881`、坐标 `(1.7,2.2)`；只有 adapter 订阅 Gazebo 世界 `/pose/info` 真值。
14. **无 `/scan` 运行依赖**：最终 Office RPG 运行时 topic/node 列表中没有 `/scan` 或 `pointcloud_to_laserscan` 节点。
15. **未配置 API Key 安全回退**：未设置 `DEEPSEEK_API_KEY`，DeepSeek provider 骨架解析“去906”后返回 `API未配置，已回退 Offline`，无异常且 UI 只显示布尔配置状态。
16. **Ctrl-C 清理**：直接 launch 的 Gazebo、parameter bridge、ROS Python 节点和 Streamlit 均响应 SIGINT 并退出；一键脚本还跟踪所有子 PID 并在 trap 中发送 SIGINT/wait。
17. **用户修改保留**：验收后 `git status --short` 仍保留审计基线中的相邻包和本包用户修改；未执行任何覆盖/清理/提交/推送操作。

## 静态检查通过

- `ign sdf -k worlds/corridor_902_904_906_908.sdf`：Valid。
- 新增/受影响 Python `compileall` 通过；shell `bash -n` 通过；包构建通过。
- `web_ui` 源码无 `/cmd_vel` publisher；只发布 mission/provider，并调用 stop/reset。
- 新 Office launch 明确 `use_pointcloud_to_laserscan:=false`，且不包含 LaserScan bridge。
- `ranger_mid360s.launch.py` 保留旧转换节点但加默认 false condition，PointCloud2 `/livox/lidar` 保留。
- API Key 未写入配置、源码或 UI；只检查环境变量是否非空。
- Streamlit bridge 是 process singleton + `st.cache_resource`，一个后台 `MultiThreadedExecutor`，rerun 读取加锁缓存。
- provider 输出仅为 `MissionPlan` JSON 语义，不含速度/底盘命令。

## 尚未实现（按 Phase 1 范围停止）

- 完整 find-person 跨候选区域导航执行、未找到后的下一候选切换。
- 到达候选区域后由 manager 自动触发视觉、身份确认、安全距离停车和 reminder completion。
- 真实 DeepSeek HTTP 调用、真实 Local Qwen 调用。
- 人脸识别或 D435i 真实人员检测。
- FAST-LIO、MID360S 3D Nav2、PointCloud2 VoxelLayer 闭环。
- Nav2 action goal 的发送/取消；当前运行闭环是现有 `/task_control STOP` + watchdog 安全链。
- lab 新区域。

人员任务在 Phase 1 会被解析和展示为 `PLANNED_PHASE_1`，不会伪装成已完成。

## 已知问题

- 主机全局 `/home/zbx/cyclonedds_pc.xml` 绑定旧 IP，直接继承该环境会导致 DDS node creation 失败；一键脚本提供 process-local Fast DDS fallback。
- `/home/zbx/.bash_profile` 当前有不匹配引号，login shell 会打印语法错误；项目脚本使用非交互 source 路径，不修改该用户文件。
- 现有部分 Python 节点在 ROS launch 收到 SIGINT 后会因 rclpy signal handler 已 shutdown 而打印二次 shutdown traceback；进程仍退出、Gazebo/bridge cleanly exit。这是旧节点清理逻辑问题，本 Phase 1 未扩大修改范围。
- UI“重置场景”当前重置 mission 状态和 NPC 日程并安全停车，不重置 Ranger 的 Gazebo 世界位姿。
- 旧 benchmark world/launch 仍保留历史 `/scan` 接口，符合“不直接删除”限制；Office RPG launch 与它隔离且不依赖 `/scan`。
- `use_llm` 参数为 Phase 1 接口占位；远程调用刻意未启用。
