# Office RPG Phase 1.5 验收记录

验收日期：2026-07-19（Asia/Shanghai）

范围：仅实施“信息受限的任务搜索、定时巡检与条件任务”。未接入真实 D435i、人脸识别、DeepSeek HTTP、FAST-LIO、PointCloud2/VoxelLayer 或真实硬件。

## 状态机与信息边界

确定性执行器状态为：

```text
PARSE_TASK -> PLAN_SEARCH -> NAVIGATE_TO_REGION -> OBSERVE_REGION
           -> UPDATE_BELIEF -> IDENTIFY_TARGET -> DELIVER_MESSAGE
           -> PATROL_CHECKPOINT -> GENERATE_REPORT
           -> COMPLETED | FAILED | STOPPED
```

执行器只订阅 MissionSpec、Ranger `/odom`、仿真时间和按请求产生的普通检测事件。它用 YAML 日程先验、观察点、候选概率、路径代价、negative observation 和 last_seen 规划；没有 Gazebo pose、NPC schedule 真值或 `/office_rpg/sim/*` 订阅。

Gazebo NPC 坐标只进入 `simulation_perception_adapter`。普通 `/office_rpg/npc_states` 只含 `UNKNOWN/LAST_SEEN/CONFIRMED` 和已发现目标的 last_seen；精确坐标仅发布到开发者话题 `/office_rpg/sim/npc_ground_truth`。Streamlit 默认不订阅该话题，开发者开关只动态创建/销毁可视化订阅。

## 真实运行通过

1. **分散出生与日程时间初始化**：Ranger 初始位置为 `(1.20, 2.30)`；seed 17 下访客约 `(2.616, 1.546)`、张老师初始位于 904 区、李同学约 `(17.813, 4.089)`，未在 Ranger 附近集中出生。`initial_time=85` 启动时张老师直接处于 904→906 日程段，没有从公共出生点穿行。
2. **随机种子可复现**：同一 seed 17 对同一 NPC/区域两次偏移完全相同 `(-0.0277985,-0.0328056)`；seed 18 得到不同合法小偏移 `(-0.0092757,-0.0053816)`。
3. **普通 UI 不泄露真值**：8502 页面实际由无头 Chrome 渲染；普通模式下 `/office_rpg/sim/npc_ground_truth` 的 subscription count 为 0，三个人员均显示 `UNKNOWN`。ROS 图中不存在 Streamlit 到 `/cmd_vel` 的 publisher，验收时 Office RPG 运行图也没有 `/cmd_vel` 话题。
4. **开发者真值仅改变显示**：Streamlit AppTest 实际切换开关，开启时创建真值订阅并显示红色 `SIMULATION GROUND TRUTH — NOT AVAILABLE ON REAL ROBOT`，关闭后销毁订阅并清空缓存；切换前后 mission status/search plan 字节级不变。测试进程安全退出。
5. **第一候选命中并提醒**：`initial_time=0` 重置后发送“找到张老师，提醒他十点去906开会”，Ranger 实际导航到 904 观察点、触发 adapter 后完成；最终 `COMPLETED`、`teacher_zhang=CONFIRMED`、last_seen 仅为 `room_904`、提醒内容正确、`truth_access=NONE`。
6. **负观测后换区**：`initial_time=85` 时仍按先验/代价先搜索 904；到达后产生 negative observation，候选概率由 `0.85/0.15` 更新约为 `0.2208/0.7792`，随后真实重定向到 906 并完成。为此修复了运行时重定向时保留 lobby 后方旧 waypoint 的问题；904→906 实测约 15 秒到达。
7. **条件任务 fallback**：以 `perception_forced_target_misses=1` 发送“找到李同学提醒交报告；如果第一次没找到，巡检908后再找一次。”第一次在 908 返回 `configured_acceptance_forced_miss`，执行 fallback 巡检 908 后重试并完成；最终 `COMPLETED`、`retry_count=1`、`fallback_active=true`、李同学 `CONFIRMED`、消息为“交报告”。
8. **多 checkpoint 巡检与报告**：实际执行“立即执行一次办公室巡检”，依次到达 `lobby -> room_904 -> room_906`，最终 `COMPLETED`。结构化 report 含开始/结束时间、三个已访问点、空遗漏列表、每点导航结果和 detections、访客/张老师发现记录、失败列表及最终状态；lobby 访客触发通知队列事件。
9. **STOP 立即生效**：在 `SEARCH_PERSON/NAVIGATE_TO_REGION` 状态和 `PATROL_CHECKPOINT` 状态分别调用 `/office_rpg/stop`，两次均返回 success，状态立即变为 `STOPPED`、planned path 清空；`/cmd_vel_safe` 实测六个分量均为 0。
10. **原 benchmark 独立启动**：单独实际启动 `corridor_semantic_benchmark.launch.py use_gazebo:=true launch_rviz:=false`，原 detector/memory/planner/filter/watchdog/logger/odom 全部出现，Gazebo 模型列表仍含原房间、门、障碍、`rangermini_2_0` 和三个 NPC。
11. **Streamlit 8502**：`/_stcore/health` 返回 `ok`，页面实际渲染任务控制、预设、信息受限俯视图、状态机阶段、候选概率/队列、人员知识、报告与时间线。
12. **Ctrl-C 清理**：结束 Gazebo、Streamlit 和 ROS launch 后从宿主机进程表检查，除检查命令自身外，无 `ign gazebo`、Office RPG 或 8502 Streamlit 残留。

## 静态检查通过

- Offline provider 解析导航、找人、找人提醒、条件重试、立即巡检和每天 8 点巡检示例；可选 provider 失败路径安全回退 Offline。
- Python compile、YAML 加载、shell `bash -n`、SDF `ign sdf -k` 和 `colcon build --packages-select rangermini_doorway_sim --symlink-install` 通过。
- Office launch 默认 `use_pointcloud_to_laserscan=false`，桥接列表不含 `/scan`，运行时无 `/scan` 或转换节点。
- 旧 benchmark 的历史 `/scan` 接口按约束保留，独立于 Office RPG。
- 前端源码不发布速度；停止只调用 `/office_rpg/stop`。
- API Key 只做布尔存在性检查，源码、状态和页面均不包含 Key 内容。
- 未执行 reset、checkout、clean、commit 或 push；审计前已有 dirty 修改保持存在。

## 已知问题

- 原有若干 ROS Python 节点在 launch 收到 SIGINT 后会打印“rcl_shutdown already called” traceback，但实测相关进程均退出；这是 Phase 0/1 已记录的旧清理逻辑问题。
- reset 重置任务与 NPC 日程时间原点并停车，不重置 Ranger 的 Gazebo 世界位姿。
- 每天 8 点任务在 Phase 1.5 采用“加速仿真触发”：MissionSpec 保留 `scheduled_time=08:00`，本次演示立即执行并发出 `SCHEDULE_TRIGGERED`，不是墙钟守护服务或手机推送。
- NPC 当前为彩色简化人体，身份确认仍是明确标注的 simulation stub。工作区虽有动画人物和 YOLOv8 person detector，但本机 `ultralytics` 当前因 Torch API 不完整无法加载；本阶段未把它伪装成已接通。

## 未实现（不进入 Phase 2）

- 真实 D435i、真实或仿真人脸识别、真实身份模型。
- YOLO 相机 person detection 到本任务 adapter 的像素证据融合。
- 真实 Local Qwen/DeepSeek API 调用。
- FAST-LIO、MID360 PointCloud2/VoxelLayer、完整 Nav2 action 服务器或真实硬件。
- 手机/企业消息推送、长期墙钟定时服务、持久化任务数据库。

## 启动

```bash
cd /home/zbx/ranger_ws
colcon build --packages-select rangermini_doorway_sim --symlink-install
bash src/rangermini_doorway_sim/scripts/start_office_rpg_demo.sh
```

前端：`http://localhost:8502`
